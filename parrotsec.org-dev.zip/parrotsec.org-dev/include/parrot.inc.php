<?php

require('include/config.inc.php');
require('include/lang.php');
require('include/layout.php');

?>